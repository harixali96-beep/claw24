#!/usr/bin/env bash
# 24/7 installer for the Telegram video bot (OpenClaw + professional editor).
# Ubuntu 22.04 / 24.04, root. Run with env vars:
#   TELEGRAM_BOT_TOKEN=... GOOGLE_API_KEY=... bash install.sh
set -euo pipefail

BUNDLE_URL="${BUNDLE_URL:-__BUNDLE_URL__}"
CLAW=/root/claw
EDITOR=/root/editor
NODE_MAJOR=20
OPENCLAW_VER=2026.11.5

say() { printf '\n\033[1;36m== %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31mFAILED: %s\033[0m\n' "$*" >&2; exit 1; }

[ "$(id -u)" = "0" ] || die "run as root (sudo -i first)"
[ -n "${TELEGRAM_BOT_TOKEN:-}" ] || die "TELEGRAM_BOT_TOKEN is not set"

say "1/8 system packages"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq ffmpeg python3 python3-venv python3-pip curl ca-certificates git tar >/dev/null

say "2/8 Node.js $NODE_MAJOR"
if ! command -v node >/dev/null || [ "$(node -v | cut -c2- | cut -d. -f1)" -lt "$NODE_MAJOR" ]; then
  curl -fsSL "https://deb.nodesource.com/setup_${NODE_MAJOR}.x" | bash - >/dev/null 2>&1
  apt-get install -y -qq nodejs >/dev/null
fi
node -v

say "3/8 OpenClaw $OPENCLAW_VER"
npm install -g "openclaw@${OPENCLAW_VER}" --silent >/dev/null 2>&1 || npm install -g "openclaw@${OPENCLAW_VER}" >/dev/null
command -v openclaw >/dev/null || die "openclaw not installed"

say "4/8 professional editor bundle"
mkdir -p /root/pkg
curl -fsSL "$BUNDLE_URL" -o /root/pkg/claw24.tar.gz || die "bundle download failed"
tar -xzf /root/pkg/claw24.tar.gz -C /root/pkg
rm -rf "$EDITOR"
mv /root/pkg/claw24/editor "$EDITOR"
[ -f "$EDITOR/engine.py" ] || die "editor bundle incomplete"

say "5/8 python env (whisper + yt-dlp)"
python3 -m venv "$EDITOR/venv"
"$EDITOR/venv/bin/pip" install -q --upgrade pip
"$EDITOR/venv/bin/pip" install -q faster-whisper yt-dlp
"$EDITOR/venv/bin/python" -c "import faster_whisper" || die "faster-whisper import failed"

say "6/8 bot config"
mkdir -p "$CLAW/state" "$CLAW/workspace"
TELEGRAM_BOT_TOKEN="$TELEGRAM_BOT_TOKEN" "$EDITOR/venv/bin/python" "$EDITOR/setup_config.py" --claw "$CLAW" --editor "$EDITOR"
chmod 600 "$CLAW/state/openclaw.json"
[ -n "${GOOGLE_API_KEY:-}" ] && printf 'GOOGLE_API_KEY=%s\n' "$GOOGLE_API_KEY" > /root/.claw.env && chmod 600 /root/.claw.env

say "7/8 systemd service (auto restart, starts on boot)"
cat > /etc/systemd/system/openclaw.service <<UNIT
[Unit]
Description=OpenClaw video bot
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=$CLAW
Environment=OPENCLAW_STATE_DIR=$CLAW/state
Environment=OPENCLAW_CONFIG_PATH=$CLAW/state/openclaw.json
Environment=PATH=/usr/local/bin:/usr/bin:/bin
EnvironmentFile=-/root/.claw.env
ExecStart=$(command -v openclaw) gateway run
Restart=always
RestartSec=5
StandardOutput=append:/var/log/openclaw.log
StandardError=append:/var/log/openclaw.log

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable openclaw >/dev/null 2>&1
systemctl restart openclaw
sleep 20

say "8/8 verify"
export OPENCLAW_STATE_DIR="$CLAW/state" OPENCLAW_CONFIG_PATH="$CLAW/state/openclaw.json"
timeout 25 openclaw gateway health 2>&1 | head -3 || true
timeout 30 openclaw channels status 2>&1 | grep -i telegram | head -2 || true
echo
systemctl is-active openclaw
echo
echo "Log:     tail -f /var/log/openclaw.log"
echo "Restart: systemctl restart openclaw"
echo "Editor:  $EDITOR/tools/proedit.py"
echo
echo "Done. Ab Telegram par @cliping_video_bot ko message karo."
