#!/usr/bin/env python3
"""
chatcut web - chat to edit, in the browser.

Run locally:      python3 app.py
Hugging Face:     upload this folder as a Gradio Space (see README)

Everything runs on the machine that hosts it. No API keys, no accounts.
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import autoclip  # noqa: E402
import engine  # noqa: E402
import router  # noqa: E402
import timeline_ui  # noqa: E402
import styles  # noqa: E402

UPLOAD_DIR = os.environ.get("CHATCUT_WORK", os.path.join(tempfile.gettempdir(), "chatcut-web"))
os.makedirs(UPLOAD_DIR, exist_ok=True)

PRESETS = [
    "silence hatao, captions lagao, shorts banao",
    "silence hatao, face tracking karo, captions lagao, sfx dalo",
    "podcast split karo, captions lagao, background music dalo",
    "pehle 45 seconds lo, 1.5x speed karo, cinematic lagao",
    "body track karo, zoom karo, noir effect lagao, captions lagao",
]


# ---------------------------------------------------------------- helpers
def fetch_link(url, workdir):
    """Download a YouTube / Drive / direct link. Returns a local file path."""
    url = (url or "").strip()
    if not url:
        return None, "no link"
    target = os.path.join(workdir, "download.mp4")
    if "drive.google.com" in url:
        try:
            import gdown
            out = gdown.download(url, target, quiet=True, fuzzy=True)
            if out and os.path.exists(out):
                return out, "drive"
        except Exception:
            pass
    try:
        exe = shutil.which("yt-dlp") or "yt-dlp"
        cmd = [exe, "-f", "bv*[height<=1080]+ba/b[height<=1080]/b",
               "--merge-output-format", "mp4", "-o", target, "--no-playlist", url]
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
        if p.returncode == 0 and os.path.exists(target):
            return target, "yt-dlp"
        return None, (p.stderr.strip().splitlines() or ["download failed"])[-1]
    except Exception as exc:
        return None, f"download failed: {exc}"


def resolve_source(video_file, url, workdir):
    if video_file:
        dest = os.path.join(workdir, "input" + (os.path.splitext(video_file)[1] or ".mp4"))
        shutil.copyfile(video_file, dest)
        return dest, "upload"
    u = (url or "").strip()
    if u.startswith("file://"):
        u = u[7:]
    if u and os.path.exists(u):
        dest = os.path.join(workdir, "input" + (os.path.splitext(u)[1] or ".mp4"))
        shutil.copyfile(u, dest)
        return dest, "local path"
    if u:
        return fetch_link(u, workdir)
    return None, "upload a file or paste a link"


def log_line(lines, text):
    lines.append(str(text))
    return "\n".join(lines)


# ------------------------------------------------------------------ core
def run_edit(video_file, url, instruction, style_choice, music_file, want_desc,
             model_choice, use_llm=False, progress=None):
    lines = []
    workdir = tempfile.mkdtemp(prefix="chatcut-run-", dir=UPLOAD_DIR)
    try:
        src, how = resolve_source(video_file, url, workdir)
        if not src:
            return (None, log_line(lines, f"**Cannot start:** {how}"), "", None,
                    {"error": how})
        info = engine.probe(src)
        log_line(lines, f"**Source ready** ({how}) - {info['duration']:.1f}s, "
                        f"{info['width']}x{info['height']}")
        if not (instruction or "").strip():
            return (None, log_line(lines, "**Nothing to do:** type an instruction."),
                    "", None, {"error": "empty instruction"})

        planned = router.plan(instruction) if use_llm else {
            "ops": engine.parse_instruction(instruction), "source": "rules"}
        ops = engine.order_ops(planned["ops"])
        if use_llm:
            log_line(lines, f"**Router:** {planned['source']} "
                            f"({planned.get('note', '')})")
        if not ops:
            return (None, log_line(lines, "**Not understood:** try wording like "
                                         "\"silence hatao, captions lagao, shorts banao\"."),
                    "", None, {"error": "no ops parsed"})
        log_line(lines, "**Plan:** " + ", ".join(o["op"] for o in ops))

        music = music_file or None
        style = None if style_choice in (None, "", "auto") else style_choice
        out = os.path.join(workdir, "out.mp4")

        result = engine.edit(
            src, instruction, out, srt=None, music=music, style=style,
            auto_transcribe=True, model=model_choice or None,
            want_description=bool(want_desc),
            tl_dir=os.path.join(workdir, "timeline"),
        )

        for s in result.get("steps", []):
            if s.get("skipped"):
                log_line(lines, f"- `{s['op']}` skipped: {s['skipped']}")
            elif s["op"] == "captions":
                log_line(lines, f"- captions: {s.get('style')} ({s.get('ass_lines')} lines)"
                                + (", retimed" if s.get("retimed") else ""))
            elif s["op"] == "podcast":
                log_line(lines, f"- podcast split: {s.get('panel')} panels")
            elif s["op"] == "track":
                log_line(lines, f"- tracking: {s.get('faces')} faces, "
                                f"{s.get('path_points')} path points")
            else:
                extra = {k: v for k, v in s.items() if k not in ("op",)}
                log_line(lines, f"- `{s['op']}` {json.dumps(extra, default=float)}")

        tr = result.get("transcript") or {}
        if tr.get("auto"):
            log_line(lines, f"**Transcribed** with whisper-{tr.get('model')} "
                            f"({tr.get('language')}, {tr.get('word_count')} words)")
        elif tr.get("error"):
            log_line(lines, f"**Transcription:** {tr['error']}")

        res = result.get("result") or {}
        log_line(lines, f"**Done** - {res.get('duration')}s, {res.get('size')}")

        srt_path = os.path.join(workdir, "captions.srt")
        if tr.get("segments"):
            with open(srt_path, "w", encoding="utf-8") as fh:
                fh.write(engine_srt(tr["segments"]))
        else:
            srt_path = None

        desc_text = ""
        if want_desc and result.get("description"):
            d = result["description"]
            desc_text = d.get("description") or json.dumps(d, indent=2, ensure_ascii=False)

        return (out, "\n".join(lines), desc_text, srt_path, result)
    except Exception as exc:
        tb = traceback.format_exc(limit=3)
        return (None, log_line(lines, f"**Failed:** {exc}\n\n```\n{tb}\n```"),
                "", None, {"error": str(exc)})
    finally:
        pass


def engine_srt(segments):
    def ts(t):
        h = int(t // 3600); m = int(t % 3600 // 60); s = t % 60
        return f"{h:02d}:{m:02d}:{s:06.3f}".replace(".", ",")
    out = []
    for i, s in enumerate(segments, 1):
        out.append(f"{i}\n{ts(s['start'])} --> {ts(s['end'])}\n{s['text']}")
    return "\n\n".join(out) + "\n"


# -------------------------------------------------------------- auto clips
def run_clips(video_file, url, count, min_len, max_len, style_choice, facecam,
              model_choice):
    if not video_file and not (url or "").strip():
        return [], None, "**Upload a video or paste a link first.**"
    wd = tempfile.mkdtemp(prefix="chatcut-autoclip-", dir=UPLOAD_DIR)
    src, how = resolve_source(video_file, url, wd)
    if not src:
        return [], None, f"**Cannot start:** {how}"
    outdir = os.path.join(wd, "clips")
    lines = []
    try:
        res = autoclip.auto_clip(
            src, outdir, n=int(count), min_len=float(min_len),
            max_len=float(max_len), model=model_choice or None,
            style=None if style_choice in (None, "", "auto") else style_choice,
            want_facecam=bool(facecam),
            progress=lambda m: lines.append(f"- {m}"))
    except Exception as exc:
        return [], None, f"**Failed:** {exc}"
    if not res.get("ok"):
        return [], res, f"**No clips:** {res.get('reason')}"

    files = [c["file"] for c in res["clips"] if c.get("file")]
    table = ["| # | time | len | score | title |", "|---|---|---|---|---|"]
    for c in res["clips"]:
        if not c.get("file"):
            continue
        w = c["window"]
        table.append(f"| {c['index']} | {w['start']:.0f}-{w['end']:.0f}s | "
                     f"{w['duration']:.0f}s | {c['score']} | {c['title']} |")
    head = [f"**{res['produced']} of {res['requested']} clips** from "
            f"{res['source_duration']:.0f}s of source "
            f"({res['candidates_considered']} windows scored)"]
    if res.get("note"):
        head.append(f"_{res['note']}_")
    return files, res, "\n\n".join(head + ["\n".join(table)])


# -------------------------------------------------------------- timeline
def load_timeline(video_file, url):
    """Give the draggable timeline something to show: the whole source as one clip."""
    if not video_file and not (url or "").strip():
        return (json.dumps({"duration": 0, "segments": []}), None,
                "Upload a video or paste a link first.")
    wd = tempfile.mkdtemp(prefix="chatcut-tl-", dir=UPLOAD_DIR)
    src, how = resolve_source(video_file, url, wd)
    if not src:
        return (json.dumps({"duration": 0, "segments": []}), None,
                f"Cannot load: {how}")
    info = engine.probe(src)
    dur = round(info["duration"], 2)
    payload = {"duration": dur, "segments": [{"start": 0.0, "end": dur}]}
    note = (f"Timeline ready ({how}, {dur:.1f}s, {info['width']}x{info['height']}). "
            f"Drag a clip to reorder, drag its edges to trim, then render.")
    return json.dumps(payload), src, note


def render_tl(json_text, src):
    if not src:
        return None, "**Load a timeline first.**"
    try:
        data = json.loads(json_text or "{}")
    except Exception as exc:
        return None, f"**Bad timeline JSON:** {exc}"
    segs = data.get("segments") if isinstance(data, dict) else data
    if not segs:
        return None, "**Timeline has no clips.**"
    wd = tempfile.mkdtemp(prefix="chatcut-tlrender-", dir=UPLOAD_DIR)
    out = os.path.join(wd, "timeline.mp4")
    try:
        res = engine.render_timeline(src, segs, out)
        lines = [f"**Rendered {len(res['segments'])} clips** "
                 f"→ {res['result']['duration']}s, {res['result']['size']}"]
        for i, sg in enumerate(res["segments"], 1):
            lines.append(f"- clip {i}: {sg['start']}s → {sg['end']}s")
        return out, "\n".join(lines)
    except Exception as exc:
        return None, f"**Failed:** {exc}"


# ------------------------------------------------------------------ ui
def build_ui():
    import gradio as gr

    with gr.Blocks(title="chatcut") as demo:
        gr.Markdown(
            "# chatcut\n"
            "Chat to edit video. Free, local, open source. "
            "Upload a clip or paste a link, then just say what you want."
        )
        tl_state = gr.State(None)

        with gr.Tab("Edit"):
            with gr.Row():
                with gr.Column(scale=1):
                    video_in = gr.Video(label="Video (upload)", sources=["upload"])
                    url_in = gr.Textbox(
                        label="...or a link",
                        placeholder="YouTube / Google Drive / direct MP4 URL")
                    instruction = gr.Textbox(
                        label="Chat instruction",
                        value=PRESETS[0], lines=3,
                        placeholder="silence hatao, captions lagao, shorts banao")
                    gr.Examples(examples=[[p] for p in PRESETS], inputs=[instruction],
                                label="Try one")
                    with gr.Row():
                        style_choice = gr.Dropdown(
                            ["auto"] + styles.style_names(), value="auto",
                            label="Caption style")
                        model_choice = gr.Dropdown(
                            ["tiny", "base", "small"], value="tiny",
                            label="Whisper model")
                    music_in = gr.Audio(label="Music bed (optional)", type="filepath")
                    want_desc = gr.Checkbox(
                        label="Generate title, summary and hashtags", value=True)
                    use_llm = gr.Checkbox(
                        label="Route with a local model if one is running "
                              "(free, no key, falls back to the parser)",
                        value=False)
                    run_btn = gr.Button("Edit", variant="primary")

                with gr.Column(scale=1):
                    video_out = gr.Video(label="Result")
                    log_out = gr.Markdown(label="What the agent did")
                    with gr.Accordion("Description (Descript-style)", open=False):
                        desc_out = gr.Textbox(lines=14, show_label=False)
                    srt_out = gr.File(label="Captions (.srt)")
                    json_out = gr.JSON(label="Full report", visible=False)

            run_btn.click(
                run_edit,
                inputs=[video_in, url_in, instruction, style_choice, music_in,
                        want_desc, model_choice, use_llm],
                outputs=[video_out, log_out, desc_out, srt_out, json_out],
            )

        with gr.Tab("Auto clips"):
            gr.Markdown(
                "Drop in a long stream, podcast or gameplay VOD. The tool "
                "transcribes it, scores every candidate window on speech density "
                "and hook language, then cuts the best ones into vertical clips "
                "with captions. Streamer footage keeps the facecam strip on top."
            )
            with gr.Row():
                clips_btn = gr.Button("Make clips", variant="primary")
                clips_count = gr.Slider(1, 8, value=3, step=1, label="How many")
                clips_min = gr.Slider(8, 60, value=15, step=1, label="Min length (s)")
                clips_max = gr.Slider(15, 90, value=45, step=1, label="Max length (s)")
            clips_facecam = gr.Checkbox(
                label="Use the facecam layout when the source has one", value=True)
            clips_log = gr.Markdown()
            clips_files = gr.File(label="Clips", file_count="multiple")
            clips_json = gr.JSON(label="Report", visible=False)

            clips_btn.click(
                run_clips,
                inputs=[video_in, url_in, clips_count, clips_min, clips_max,
                        style_choice, clips_facecam, model_choice],
                outputs=[clips_files, clips_json, clips_log])

        with gr.Tab("Timeline"):
            gr.Markdown(
                "Drag a clip to reorder it. Drag its left or right edge to trim it. "
                "Then press **Render timeline**."
            )
            with gr.Row():
                load_btn = gr.Button("Load timeline", variant="primary")
                render_btn = gr.Button("Render timeline")
            tl_html = gr.HTML(
                '<div id="tl-root"><div class="tl-empty">Upload a video on the Edit '
                'tab, then press "Load timeline".</div></div>')
            tl_note = gr.Markdown()
            tl_json = gr.Textbox(label="Timeline JSON (live, editable)", lines=4,
                                 elem_id="tl_json")
            tl_video = gr.Video(label="Timeline result")
            tl_log = gr.Markdown()

            load_btn.click(load_timeline, inputs=[video_in, url_in],
                           outputs=[tl_json, tl_state, tl_note]).then(
                fn=None, inputs=[tl_json], js=timeline_ui.TL_MOUNT_JS)
            render_btn.click(render_tl, inputs=[tl_json, tl_state],
                             outputs=[tl_video, tl_log])

        gr.Markdown(
            "Ops: trim, cut_silence, vertical, track (face/body), podcast, zoom, "
            "effects, loudnorm, speed, fade, captions, sfx, music. "
            "120 caption styles, 19 effects. Nothing leaves this machine."
        )
    return demo


if __name__ == "__main__":
    ui = build_ui()
    import gradio as _gr
    ui.launch(server_name="0.0.0.0",
              server_port=int(os.environ.get("PORT", 7860)),
              theme=_gr.themes.Soft(),
              css=timeline_ui.TL_CSS,
              show_error=True)
