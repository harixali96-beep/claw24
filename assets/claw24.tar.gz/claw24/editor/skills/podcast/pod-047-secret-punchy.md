---
name: pod-047-secret-punchy
category: podcast
hook: secret
pacing: punchy
platform: Shorts
---
# secret / punchy

**When to use:** a podcast episode has to become a vertical clip
**Hook rule:** withhold the payoff until 70% (Promise something nobody told them.)

## Recipe
1. Transcribe with whisper (`proedit.py` does this automatically).
2. Pick the window with the strongest secret signal; keep it 30s.
3. Cut every **1.8s** (~7 shots) so nothing breathes too long.
4. Captions: style `teal-punch-flip-in`, 3-5 words per line, uppercase keywords.
5. SFX: `swoosh-05 / boom-01` on every cut point.
6. Split speakers top/bottom when two people talk in the same shot.
7. Cut on the laugh or the disagreement, not on a breath.
8. Name the speaker in the caption when the voice changes.

## Command
```
python3 tools/proedit.py "<src>" "<outdir>" --seconds 30 --n 1 --fastcut 1.8 --style teal-punch-flip-in
```

## Check before sending
- first 2 seconds contain the secret hook
- caption text is legible at 1080x1920 (no line over 5 words)
- every cut has an sfx hit, audio never clips
