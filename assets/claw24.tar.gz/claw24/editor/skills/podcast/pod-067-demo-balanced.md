---
name: pod-067-demo-balanced
category: podcast
hook: demo
pacing: balanced
platform: Reels
---
# demo / balanced

**When to use:** a podcast episode has to become a vertical clip
**Hook rule:** visual proof in cut 1 (Show the result first, explain after.)

## Recipe
1. Transcribe with whisper (`proedit.py` does this automatically).
2. Pick the window with the strongest demo signal; keep it 30s.
3. Cut every **3.0s** (~4 shots) so nothing breathes too long.
4. Captions: style `hot-pink-shake`, 3-5 words per line, uppercase keywords.
5. SFX: `swoosh-05 / boom-01` on every cut point.
6. Split speakers top/bottom when two people talk in the same shot.
7. Cut on the laugh or the disagreement, not on a breath.
8. Name the speaker in the caption when the voice changes.

## Command
```
python3 tools/proedit.py "<src>" "<outdir>" --seconds 30 --n 1 --fastcut 3.0 --style hot-pink-shake
```

## Check before sending
- first 2 seconds contain the demo hook
- caption text is legible at 1080x1920 (no line over 5 words)
- every cut has an sfx hit, audio never clips
