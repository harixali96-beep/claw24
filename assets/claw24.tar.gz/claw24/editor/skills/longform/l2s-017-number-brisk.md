---
name: l2s-017-number-brisk
category: long-to-short
hook: number
pacing: brisk
platform: Shorts
---
# number / brisk

**When to use:** a long video has to become one vertical short
**Hook rule:** number spoken before cut 1 (Put a concrete number in the first 2 seconds.)

## Recipe
1. Transcribe with whisper (`proedit.py` does this automatically).
2. Pick the window with the strongest number signal; keep it 20s.
3. Cut every **2.5s** (~4 shots) so nothing breathes too long.
4. Captions: style `bold-yellow-pop`, 3-5 words per line, uppercase keywords.
5. SFX: `whoosh-03 / impact-02` on every cut point.
6. Zoom in 5-8% on the punchline word, out on the pause.
7. Keep the payoff in the last 3 seconds so the loop restarts.

## Command
```
python3 tools/proedit.py "<src>" "<outdir>" --seconds 20 --n 1 --fastcut 2.5 --style bold-yellow-pop
```

## Check before sending
- first 2 seconds contain the number hook
- caption text is legible at 1080x1920 (no line over 5 words)
- every cut has an sfx hit, audio never clips
