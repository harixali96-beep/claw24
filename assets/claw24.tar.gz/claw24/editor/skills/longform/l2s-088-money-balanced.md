---
name: l2s-088-money-balanced
category: long-to-short
hook: money
pacing: balanced
platform: Reels
---
# money / balanced

**When to use:** a long video has to become one vertical short
**Hook rule:** amount or percentage (Frame it as money saved or made.)

## Recipe
1. Transcribe with whisper (`proedit.py` does this automatically).
2. Pick the window with the strongest money signal; keep it 20s.
3. Cut every **3.0s** (~4 shots) so nothing breathes too long.
4. Captions: style `bold-white-bounce`, 3-5 words per line, uppercase keywords.
5. SFX: `whoosh-03 / impact-02` on every cut point.
6. Zoom in 5-8% on the punchline word, out on the pause.
7. Keep the payoff in the last 3 seconds so the loop restarts.

## Command
```
python3 tools/proedit.py "<src>" "<outdir>" --seconds 20 --n 1 --fastcut 3.0 --style bold-white-bounce
```

## Check before sending
- first 2 seconds contain the money hook
- caption text is legible at 1080x1920 (no line over 5 words)
- every cut has an sfx hit, audio never clips
