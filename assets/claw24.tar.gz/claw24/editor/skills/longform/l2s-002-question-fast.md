---
name: l2s-002-question-fast
category: long-to-short
hook: question
pacing: fast
platform: Shorts
---
# question / fast

**When to use:** a long video has to become one vertical short
**Hook rule:** first line must be a question (Open with the exact question the viewer already has in their head.)

## Recipe
1. Transcribe with whisper (`proedit.py` does this automatically).
2. Pick the window with the strongest question signal; keep it 20s.
3. Cut every **2.0s** (~5 shots) so nothing breathes too long.
4. Captions: style `neon-green-karaoke`, 3-5 words per line, uppercase keywords.
5. SFX: `whoosh-03 / impact-02` on every cut point.
6. Zoom in 5-8% on the punchline word, out on the pause.
7. Keep the payoff in the last 3 seconds so the loop restarts.

## Command
```
python3 tools/proedit.py "<src>" "<outdir>" --seconds 20 --n 1 --fastcut 2.0 --style neon-green-karaoke
```

## Check before sending
- first 2 seconds contain the question hook
- caption text is legible at 1080x1920 (no line over 5 words)
- every cut has an sfx hit, audio never clips
