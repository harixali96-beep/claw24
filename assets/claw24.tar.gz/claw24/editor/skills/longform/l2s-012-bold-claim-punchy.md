---
name: l2s-012-bold-claim-punchy
category: long-to-short
hook: bold-claim
pacing: punchy
platform: TikTok
---
# bold-claim / punchy

**When to use:** a long video has to become one vertical short
**Hook rule:** no hedging words (Lead with the most controversial true statement in the clip.)

## Recipe
1. Transcribe with whisper (`proedit.py` does this automatically).
2. Pick the window with the strongest bold-claim signal; keep it 20s.
3. Cut every **1.8s** (~7 shots) so nothing breathes too long.
4. Captions: style `lime-slam-zoom-punch`, 3-5 words per line, uppercase keywords.
5. SFX: `whoosh-03 / impact-02` on every cut point.
6. Zoom in 5-8% on the punchline word, out on the pause.
7. Keep the payoff in the last 3 seconds so the loop restarts.

## Command
```
python3 tools/proedit.py "<src>" "<outdir>" --seconds 20 --n 1 --fastcut 1.8 --style lime-slam-zoom-punch
```

## Check before sending
- first 2 seconds contain the bold-claim hook
- caption text is legible at 1080x1920 (no line over 5 words)
- every cut has an sfx hit, audio never clips
