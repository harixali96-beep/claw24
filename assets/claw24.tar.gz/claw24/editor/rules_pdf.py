#!/usr/bin/env python3
"""
Generate the chatcut editing-rules PDF.

The rules are the single source of truth for how chat turns into an edit.
Keep this file in sync with engine.RULES, engine.EFFECTS and engine.EXEC_ORDER.
"""
import os

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (KeepTogether, PageBreak, Paragraph, Spacer,
                                Table, TableStyle)

ACCENT = colors.HexColor("#1F2937")
MUTED = colors.HexColor("#6B7280")
RULE = colors.HexColor("#D1D5DB")
BAND = colors.HexColor("#F3F4F6")

OPS = [
    ("trim", '"pehle 30 second", "first 2 minutes"',
     "Keep the head of the clip. Any \"N sec / N min\" phrase, capped at 2 hours."),
    ("cut_silence", '"silence hatao", "remove pauses", "chupchupati hatao"',
     "Detect silences below -32 dB lasting 0.5s or more, cut them, rejoin the rest. "
     "Cut points are recorded for SFX placement."),
    ("track", '"face tracking karo", "body track karo", "chehra track karo"',
     "Follow one subject into 9:16. Face mode centres the head; body mode anchors "
     "on the chest so the framing does not crop at the neck."),
    ("streamer", '"facecam upar", "gameplay neechay", "streamer layout"',
     "Finds the small talking head parked in a corner and stacks it as a strip on "
     "top, with the gameplay cropped underneath. Refuses when no facecam is found."),
    ("podcast", '"podcast split karo", "do log hain to upar neechay", "split screen"',
     "Two speakers get two tracked panels stacked top and bottom. When only one "
     "person is on screen the split is removed automatically and the frame returns "
     "to a normal single shot."),
    ("vertical", '"shorts", "reels", "9:16", "tiktok"',
     "Plain cover crop to 1080x1920. Dropped automatically when tracking or podcast "
     "layout already reframes the picture."),
    ("zoom", '"zoom karo", "camera movement", "punch in"',
     "Slow punch-in across the clip. Timestamps are repaired after zoompan so "
     "burned captions keep their timing."),
    ("effects", '"cinematic", "vintage", "noir", ...',
     "One graded look from 19 presets. Applied before captions so the grade never "
     "darkens the text."),
    ("loudnorm", '"awaz theek karo", "normalize audio", "loudness"',
     "EBU R128 loudness to -16 LUFS, true peak -1.5 dB."),
    ("speed", '"1.5x", "2 guna"', "Retime picture and audio together, 0.25x to 4x."),
    ("fade", '"fade lagao", "smooth"', "Fade in and out on picture and sound."),
    ("captions", '"captions lagao", "subtitles", "text"',
     "Transcribe with whisper when no SRT is supplied, then burn one of 120 animated "
     "styles. Captions are retimed onto the cut timeline automatically."),
    ("sfx", '"sfx dalo", "sound effect"', "Synthesise a whoosh at every cut point."),
    ("music", '"background music dalo", "bgm"',
     "Loop a music bed under the speech with real sidechain ducking, 8:1, "
     "15 ms attack and 350 ms release."),
]

EXEC = [
    ("1", "trim", "Cut the head first, everything after works on what is left."),
    ("2", "cut_silence", "Timing changes here, so captions are retimed later."),
    ("3", "speed", "Retime before framing so tracking sees final motion."),
    ("4", "streamer / podcast / track / vertical", "Framing. Only one survives."),
    ("5", "zoom", "Camera move on the final frame."),
    ("6", "effects", "Grade the footage, never the text."),
    ("7", "loudnorm", "Audio level after all picture timing settled."),
    ("8", "captions", "Burn text on top of the finished picture."),
    ("9", "sfx", "Place hits on the recorded cut points."),
    ("10", "music", "Bed under speech, ducked."),
    ("11", "fade", "Fade the finished programme."),
]

GUARDS = [
    ("Negation is keyword-local",
     '"captions lagao" adds captions. "captions hata do" and "captions nahi chahiye" '
     "remove them. An unrelated \"silence hatao\" earlier in the same sentence cannot "
     "switch captions off."),
    ("Split needs two people",
     'If two faces are never on screen at the same time, the split is refused with '
     '"needs two faces on screen at the same time" instead of stacking one person twice.'),
    ("Layout follows the frame",
     "Podcast layout is decided per sample, not once for the whole clip, so a second "
     "speaker entering or leaving changes the layout at that moment."),
    ("Short states never flicker",
     "Any layout state shorter than 0.8s is merged into its neighbour."),
    ("Text is never graded",
     "Effects run before captions. A vignette applied last would crush the subtitle band."),
    ("Audio survives every video step",
     "Every video filter keeps the audio stream; the podcast step maps it explicitly."),
    ("Missing input is reported, never faked",
     "No music file means the music step is skipped and says so. No transcript means "
     "whisper runs first, or the caption step reports why it could not."),
]

STYLES = [
    ("15 palettes", "bold-white, bold-yellow, neon-green, hot-pink, electric-blue, "
                    "crimson, mint, orange-pop, violet, sand, mono-box, invert, cream, "
                    "gold, ice"),
    ("8 motions", "pop, slide-up, slide-down, bounce, typewriter, karaoke, shake, "
                  "scale-in"),
    ("Total", "120 styles, named palette-motion, for example bold-yellow-pop"),
]

EFFECTS = [
    ("Look", "Names"),
    ("Cinematic", "cinematic, blockbuster, punch, anime"),
    ("Colour", "warm, cool, faded, leak, chroma"),
    ("Mono", "noir, bw"),
    ("Texture", "vintage, grain, vhs, glitch, glow, dream, soft, sharp"),
]

LIMITS = [
    ("Transcription", "faster-whisper on CPU. tiny is fast and rough, base and small "
                      "are better; the model downloads once."),
    ("Person detection", "Body framing is anchored on the detected face. There is no "
                         "skeleton or YOLO person model bundled."),
    ("Speaker switching", "The podcast layout stacks both speakers. It does not cut "
                          "between them shot by shot."),
    ("Descriptions", "Title, summary, hashtags and chapters are extractive, so they "
                     "cannot invent a claim the speaker never made. They are not a writer."),
    ("Music and SFX", "SFX are synthesised whooshes and impacts. There is no licensed "
                      "sample library."),
    ("Timeline export", "JSON, CMX3600 EDL and FCPXML 1.9, which open in Premiere, "
                        "Resolve and Final Cut. Not a native project file."),
    ("Clip scoring", "Hook detection is a keyword and density heuristic over the "
                     "transcript, not a taste model. It cannot tell whether a joke "
                     "landed, and it will not find a great silent moment."),
    ("Source footage", "GTA 6 footage does not exist publicly yet, so gameplay "
                       "support is built and tested on synthetic gameplay capture, "
                       "not on real GTA 6 video."),
    ("Free model routing", "A local model (Ollama / LM Studio) can do the routing with "
                           "no key, and its answer is validated against the real op "
                           "list. There is no hosted free API with frontier quality, "
                           "so the deterministic parser stays the default."),
]


def _styles():
    ss = getSampleStyleSheet()
    return {
        "title": ParagraphStyle("t", parent=ss["Title"], fontName="Helvetica-Bold",
                                fontSize=26, leading=30, textColor=ACCENT,
                                alignment=TA_LEFT, spaceAfter=2),
        "sub": ParagraphStyle("s", parent=ss["Normal"], fontName="Helvetica",
                              fontSize=10.5, leading=15, textColor=MUTED,
                              spaceAfter=16),
        "h2": ParagraphStyle("h2", parent=ss["Heading2"], fontName="Helvetica-Bold",
                             fontSize=13, leading=17, textColor=ACCENT,
                             spaceBefore=14, spaceAfter=6),
        "body": ParagraphStyle("b", parent=ss["Normal"], fontName="Helvetica",
                               fontSize=9.5, leading=13.5, textColor=colors.HexColor("#111827")),
        "small": ParagraphStyle("sm", parent=ss["Normal"], fontName="Helvetica",
                                fontSize=8.5, leading=12, textColor=MUTED),
        "cell": ParagraphStyle("c", parent=ss["Normal"], fontName="Helvetica",
                               fontSize=8.5, leading=11.5, textColor=colors.HexColor("#111827")),
        "code": ParagraphStyle("cd", parent=ss["Normal"], fontName="Courier",
                               fontSize=8, leading=11, textColor=colors.HexColor("#374151")),
    }


def _table(rows, widths, head=True, st=None):
    data = []
    for i, r in enumerate(rows):
        style = st["cell"]
        data.append([c if isinstance(c, Paragraph) else Paragraph(str(c), style) for c in r])
    t = Table(data, colWidths=widths, repeatRows=1 if head else 0, hAlign="LEFT")
    cmds = [
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("LINEBELOW", (0, 0), (-1, -1), 0.4, RULE),
        ("BOX", (0, 0), (-1, -1), 0.6, RULE),
    ]
    if head:
        cmds += [("BACKGROUND", (0, 0), (-1, 0), BAND),
                 ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                 ("TEXTCOLOR", (0, 0), (-1, 0), ACCENT)]
    t.setStyle(TableStyle(cmds))
    return t


def build(path):
    st = _styles()
    W = A4[0] - 40 * mm
    story = []

    story.append(Paragraph("chatcut", st["title"]))
    story.append(Paragraph(
        "Editing rules, version 3 &nbsp;·&nbsp; free and open source (MIT) "
        "&nbsp;·&nbsp; ffmpeg plus local models, no paid API", st["sub"]))

    story.append(Paragraph("How a chat turn becomes an edit", st["h2"]))
    story.append(Paragraph(
        "You type one sentence. It is parsed into an ordered list of operations. Each "
        "operation is a small deterministic ffmpeg step, run in a fixed order, and every "
        "step reports what it did or why it was skipped. The language model is only a "
        "router: it never invents a render. English and Roman Urdu are both understood.",
        st["body"]))

    story.append(Paragraph("Operations and the words that trigger them", st["h2"]))
    rows = [("Operation", "Say something like", "What it does")]
    for name, say, does in OPS:
        rows.append((Paragraph(name, st["code"]), say, does))
    story.append(_table(rows, [W * 0.16, W * 0.31, W * 0.53], st=st))

    story.append(Paragraph("Execution order, which is not negotiable", st["h2"]))
    story.append(Paragraph(
        "Order matters more than the wording. Grading before framing wastes the grade; "
        "grading after captions destroys the text.", st["body"]))
    story.append(Spacer(1, 5))
    rows = [("Step", "Operation", "Why it sits here")]
    for n, op, why in EXEC:
        rows.append((n, op, why))
    story.append(_table(rows, [W * 0.08, W * 0.26, W * 0.66], st=st))

    story.append(PageBreak())

    story.append(Paragraph("Guards: the rules that stop silent breakage", st["h2"]))
    for title, body in GUARDS:
        story.append(KeepTogether([
            Paragraph(f"<b>{title}</b>", st["body"]),
            Paragraph(body, st["body"]),
            Spacer(1, 7),
        ]))

    story.append(Paragraph("Podcast layout, the exact behaviour", st["h2"]))
    story.append(Paragraph(
        "Faces are sampled four times a second. Two or more faces means the split layout: "
        "each speaker gets a tracked 1080x960 panel, stacked into a 1080x1920 frame. One "
        "face means the split is removed and that speaker gets the full frame. A layout "
        "state shorter than 0.8 seconds is merged into its neighbour, so the picture does "
        "not strobe. Both layouts are rendered once, then cut together on the decided "
        "times, which keeps the switch sharp instead of a slow blend.", st["body"]))
    story.append(Spacer(1, 4))
    rows = [("Situation", "Result"),
            ("Two speakers on screen", "Split, top and bottom, each tracked"),
            ("One speaker on screen", "Split removed, full 9:16 of that speaker"),
            ("Second speaker enters or leaves", "Layout changes at that moment"),
            ("Two faces never seen together", "Split refused with a reason, no fake stack")]
    story.append(_table(rows, [W * 0.36, W * 0.64], st=st))

    story.append(Paragraph("Captions", st["h2"]))
    rows = [("Group", "Detail")] + STYLES
    story.append(_table(rows, [W * 0.2, W * 0.8], st=st))
    story.append(Spacer(1, 4))
    story.append(Paragraph(
        "Captions are retimed whenever a step changed the timeline, so a cut silence does "
        "not leave the subtitles behind. When no SRT is supplied, whisper transcribes "
        "first and the word timings come from that.", st["body"]))

    story.append(Paragraph("Effects", st["h2"]))
    story.append(_table(EFFECTS, [W * 0.22, W * 0.78], st=st))

    story.append(Paragraph("What this tool does not do", st["h2"]))
    story.append(Paragraph(
        "Stated plainly, because a rule that hides a limit is not a useful rule.",
        st["body"]))
    story.append(Spacer(1, 4))
    story.append(_table(LIMITS, [W * 0.24, W * 0.76], st=st))

    story.append(Paragraph("Auto clips: long video in, vertical clips out", st["h2"]))
    story.append(Paragraph(
        "The whole source is transcribed once. Candidate windows are built on sentence "
        "boundaries between the minimum and maximum length you set. Each window is "
        "scored on four things that can actually be measured: speech density (words per "
        "second), hook vocabulary, question marks and numbers, plus how close the length "
        "is to the sweet spot. Windows are taken highest score first, skipping overlaps. "
        "Each chosen window is cut, framed, captioned and given a title, summary and "
        "hashtags. If the remaining gaps are too short to fit another clip, the run says "
        "so instead of padding the result.", st["body"]))
    story.append(Spacer(1, 4))
    rows = [("Signal", "Weight", "Why"),
            ("Speech density", "2.2", "Dead air makes a weak short"),
            ("Hook vocabulary", "0.9", "Questions and stakes hold attention"),
            ("Question marks", "0.4", "A question opened is a reason to keep watching"),
            ("Numbers", "0.3", "Concrete beats vague"),
            ("Length fit", "0.6", "Peaks near 26 seconds")]
    story.append(_table(rows, [W * 0.28, W * 0.12, W * 0.6], st=st))

    story.append(Paragraph("One-line summary", st["h2"]))
    story.append(Paragraph(
        "Say it in chat, get a real render: cut, framed, graded, captioned, sounded, "
        "with a timeline you can open in a real editor and an honest note about every "
        "step that was skipped.", st["body"]))

    from reportlab.platypus import SimpleDocTemplate
    doc = SimpleDocTemplate(path, pagesize=A4,
                            leftMargin=20 * mm, rightMargin=20 * mm,
                            topMargin=18 * mm, bottomMargin=16 * mm,
                            title="chatcut editing rules", author="chatcut",
                            subject="Chat-to-edit rules")
    doc.build(story)
    return path


if __name__ == "__main__":
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       "chatcut-editing-rules.pdf")
    build(out)
    print("wrote", out, os.path.getsize(out), "bytes")
