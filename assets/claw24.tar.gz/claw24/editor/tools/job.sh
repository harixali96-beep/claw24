#!/usr/bin/env bash
# job.sh — all-in-one job for the Telegram bot: download -> notify -> edit -> send clips.
#
#   job.sh <url> [options]
#     --seconds N        target clip length (default 20)
#     --n N              how many clips (default 2)
#     --style NAME       caption style (default bold-white-bounce)
#     --fastcut SEC      cut every SEC seconds (default 2.5, 0 = no extra cuts)
#     --aspect 9:16|1:1|16:9   output aspect (default 9:16)
#     --no-captions      skip captions
#     --music FILE       music bed file
#     --chat ID          telegram chat id (default 7473905437 = owner)
#     --dry-run          do everything except sending to telegram
#     --live-minutes N   for live streams, how many minutes to record (default 10)
#
# Posts progress in Roman Urdu to Telegram, including an ETA, and sends the finished clips.
set -uo pipefail

EDITOR="${EDITOR:-$(cd "$(dirname "$0")/.." && pwd)}"
CLAW="${CLAW:-$HOME/claw}"
CHAT=7473905437
SECONDS_TARGET=20; NCLIPS=2; STYLE="bold-white-bounce"; FASTCUT=2.5
ASPECT="9:16"; CAPTIONS=1; MUSIC=""; DRY=0; LIVE_MINUTES="${LIVE_MINUTES:-10}"
URL=""

while [ $# -gt 0 ]; do
  case "$1" in
    --seconds) SECONDS_TARGET="$2"; shift 2;;
    --n) NCLIPS="$2"; shift 2;;
    --style) STYLE="$2"; shift 2;;
    --fastcut) FASTCUT="$2"; shift 2;;
    --aspect) ASPECT="$2"; shift 2;;
    --no-captions) CAPTIONS=0; shift;;
    --music) MUSIC="$2"; shift 2;;
    --chat) CHAT="$2"; shift 2;;
    --dry-run) DRY=1; shift;;
    --live-minutes) LIVE_MINUTES="$2"; shift 2;;
    -h|--help) sed -n '2,20p' "$0"; exit 0;;
    *) URL="$1"; shift;;
  esac
done
[ -n "$URL" ] || { echo "usage: job.sh <url> [options]"; exit 2; }

CAPWORD="on"; [ "$CAPTIONS" = "0" ] && CAPWORD="off"
WORK="$CLAW/work/$(date +%Y%m%d-%H%M%S)"
mkdir -p "$WORK"
LOG="$WORK/job.log"
T0=$(date +%s)
log() { echo "[$(date +%H:%M:%S)] $*" >>"$LOG"; }

tg() { # tg <text>
  local text="$1"
  log "TG: $text"
  [ "$DRY" = "1" ] && { echo "TG(dry): $text"; return 0; }
  [ -z "${TELEGRAM_BOT_TOKEN:-}" ] && return 0
  curl -s -m 25 "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage" \
    -d chat_id="$CHAT" -d parse_mode="" --data-urlencode "text=$text" >/dev/null 2>&1
}

tg_file() { # tg_file <path> <caption>
  local f="$1" cap="$2"
  [ "$DRY" = "1" ] && { echo "TG(dry) file: $f"; return 0; }
  [ -z "${TELEGRAM_BOT_TOKEN:-}" ] && return 0
  local sz; sz=$(stat -c%s "$f" 2>/dev/null || echo 0)
  if [ "$sz" -lt 50000000 ]; then
    curl -s -m 300 "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendVideo" \
      -F chat_id="$CHAT" -F supports_streaming=true -F caption="$cap" -F video=@"$f" >/dev/null 2>&1
  else
    curl -s -m 300 "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendDocument" \
      -F chat_id="$CHAT" -F caption="$cap (bara file, document)" -F document=@"$f" >/dev/null 2>&1
  fi
}

human() { local s=$1; if [ "$s" -ge 3600 ]; then echo "$((s/3600))h $(((s%3600)/60))m"; elif [ "$s" -ge 60 ]; then echo "$((s/60))m $((s%60))s"; else echo "${s}s"; fi; }

tg "📥 Download shuru: ${URL:0:120}
File aa jaye to turant bataunga, phir editing shuru."

# ---- download (with progress) -------------------------------------------------
DL="$WORK/dl"; mkdir -p "$DL"
export LIVE_MINUTES
( MAX_HEIGHT=720 "$EDITOR/tools/getvideo.sh" "$URL" "$DL" > "$WORK/getvideo.out" 2> "$WORK/getvideo.err" ) &
DLPID=$!
LASTPCT=0
while kill -0 "$DLPID" 2>/dev/null; do
  PCT=$(grep -oE "\[download\] +[0-9]+\.[0-9]+%" "$WORK/getvideo.err" 2>/dev/null | tail -1 | grep -oE "[0-9]+" | head -1)
  if [ -n "${PCT:-}" ] && [ "$PCT" -ge $((LASTPCT+25)) ] 2>/dev/null; then
    LASTPCT=$PCT
    tg "⏳ Download ${PCT}%"
  fi
  sleep 8
done
wait "$DLPID" 2>/dev/null
RESULT="$(cat "$WORK/getvideo.out" 2>/dev/null | tail -1)"

if ! printf '%s' "$RESULT" | grep -q "^OK "; then
  REASON="$(printf '%s' "$RESULT" | sed 's/^FAIL //')"
  tg "❌ Download nahi hua.

$REASON"
  log "download failed: $RESULT"
  exit 1
fi

SRC="${RESULT#OK }"
DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$SRC" 2>/dev/null | cut -d. -f1)
SZ=$(du -h "$SRC" | cut -f1)
DLTIME=$(( $(date +%s) - T0 ))
tg "✅ Video download ho gaya
• Lambai: $(human "${DUR:-0}")
• Size: $SZ
• Download time: $(human $DLTIME)

✂️ Ab editing shuru. Approx $(human $(( (DUR>1800 ? 240 : (DUR>600 ? 150 : 90)) ))) lagenge ($NCLIPS clip, ${SECONDS_TARGET}s, captions $CAPWORD, sfx on)."

# ---- edit ---------------------------------------------------------------------
ED0=$(date +%s)
OPS=(--seconds "$SECONDS_TARGET" --n "$NCLIPS" --style "$STYLE" --sfx-dir "$EDITOR/sfx")
[ "$FASTCUT" != "0" ] && OPS+=(--fastcut "$FASTCUT")
[ "$CAPTIONS" = "0" ] && OPS+=(--no-captions)
[ -n "$MUSIC" ] && OPS+=(--music "$MUSIC")
[ "$ASPECT" != "9:16" ] && OPS+=(--aspect "$ASPECT")

PY="$EDITOR/venv/bin/python"; [ -x "$PY" ] || PY=python3
( CHATCUT_DIR="$EDITOR" "$PY" "$EDITOR/tools/proedit.py" "$SRC" "$WORK/out" "${OPS[@]}" > "$WORK/edit.json" 2> "$WORK/edit.err" ) &
EDPID=$!
while kill -0 "$EDPID" 2>/dev/null; do sleep 15; done
wait "$EDPID" 2>/dev/null
EDTIME=$(( $(date +%s) - ED0 ))

if [ ! -s "$WORK/edit.json" ]; then
  tg "❌ Editing fail ho gayi. Error: $(tail -3 "$WORK/edit.err" | tr '\n' ' ' | cut -c1-300)"
  exit 1
fi

python3 - "$WORK/edit.json" "$WORK" > "$WORK/clips.txt" <<'PY'
import json,sys
d=json.load(open(sys.argv[1])); out=[]
for i,c in enumerate(d.get("clips") or [],1):
    p=c.get("output")
    if p: out.append(f"{p}|{c.get('duration')}s|{c.get('size')}|{i}")
print("\n".join(out))
PY

SENT=0
while IFS='|' read -r P D SZ2 IDX; do
  [ -z "$P" ] && continue
  [ -f "$P" ] || continue
  tg_file "$P" "Clip $IDX • ${D} • 1080x1920 • captions+sfx"
  SENT=$((SENT+1))
done < "$WORK/clips.txt"

TOTAL=$(( $(date +%s) - T0 ))
if [ "$SENT" -gt 0 ]; then
  tg "✅ Ho gaya. $SENT clip bheje ($STYLE, ${SECONDS_TARGET}s, sfx on).
Total time: $(human $TOTAL)
Aur chahiye to bolo: zyada clips, alag style, ya lamba clip."
else
  tg "⚠️ Editing chali magar koi clip nahi bana. Log: $LOG"
fi
log "done: $SENT clips in $(human $TOTAL)"
