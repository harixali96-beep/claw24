#!/usr/bin/env bash
# selfinstall.sh <git-url-or-path> [--name NAME] [--with-deps]
# Installs a repo's skills / MCP servers into the bot so the bot can use them.
# Safe by design: it copies skill files and records MCP launch commands; it never runs repo code
# unless you pass --with-deps (which only installs python requirements into the editor venv).
set -uo pipefail
SRC_URL="${1:?usage: selfinstall.sh <git-url> [--name NAME] [--with-deps]}"; shift || true
NAME=""; WITH_DEPS=0
while [ $# -gt 0 ]; do
  case "$1" in
    --name) NAME="$2"; shift 2;;
    --with-deps) WITH_DEPS=1; shift;;
    *) shift;;
  esac
done

EDITOR="${EDITOR:-$(cd "$(dirname "$0")/.." && pwd)}"
CLAW="${CLAW:-$HOME/claw}"
WS="$CLAW/workspace"
VENDOR="$EDITOR/vendor"
[ -z "$NAME" ] && NAME="$(basename "$SRC_URL" .git | tr -cd '[:alnum:]_-')"
DEST="$VENDOR/$NAME"
mkdir -p "$VENDOR" "$WS/skills/installed" "$CLAW/state"
LOG="$CLAW/state/selfinstall.log"
say() { echo "$*" | tee -a "$LOG"; }

say "== selfinstall: $SRC_URL -> $DEST"
if [ -d "$DEST/.git" ]; then
  git -C "$DEST" pull --ff-only -q 2>/dev/null || true
else
  rm -rf "$DEST"
  git clone -q --depth 1 "$SRC_URL" "$DEST" 2>>"$LOG" || { say "FAIL clone nahi hua: $SRC_URL"; exit 1; }
fi

INSTALLED=0
SKILLDIR="$WS/skills/installed/$NAME"
mkdir -p "$SKILLDIR"

# 1) any directory containing SKILL.md is a skill
while IFS= read -r f; do
  d="$(dirname "$f")"
  base="$(basename "$d")"
  mkdir -p "$SKILLDIR/$base"
  cp -a "$d/." "$SKILLDIR/$base/" 2>/dev/null
  INSTALLED=$((INSTALLED+1))
done < <(find "$DEST" -name SKILL.md -not -path "*/node_modules/*" -not -path "*/.git/*" 2>/dev/null)

# 2) conventional skills dirs
for cand in skills .agents/skills .claude/skills prompts recipes; do
  [ -d "$DEST/$cand" ] || continue
  n=$(find "$DEST/$cand" -maxdepth 2 -name "*.md" | wc -l)
  [ "$n" -eq 0 ] && continue
  mkdir -p "$SKILLDIR/${cand//\//_}"
  cp -a "$DEST/$cand/." "$SKILLDIR/${cand//\//_}/" 2>/dev/null
  INSTALLED=$((INSTALLED+n))
done

# 3) MCP servers -> registry the bot can launch on demand
python3 - "$DEST" "$NAME" "$CLAW" <<'PY'
import json, os, sys
dest, name, claw = sys.argv[1:4]
reg_path = os.path.join(claw, "state", "mcp-registry.json")
reg = {}
if os.path.exists(reg_path):
    try: reg = json.load(open(reg_path))
    except Exception: reg = {}
found = []
for f in ("mcp.json", ".mcp.json", "mcp-config.json"):
    p = os.path.join(dest, f)
    if os.path.exists(p):
        try:
            cfg = json.load(open(p))
            for sname, spec in (cfg.get("mcpServers") or cfg.get("servers") or {}).items():
                reg[f"{name}:{sname}"] = spec
                found.append(f"{name}:{sname}")
        except Exception:
            pass
for rel, cmd in (("mcp_server.py", ["python3", "{dir}/mcp_server.py"]),
                 ("server.py", ["python3", "{dir}/server.py"]),
                 ("mcp/server.js", ["node", "{dir}/mcp/server.js"]),
                 ("server/index.js", ["node", "{dir}/server/index.js"])):
    p = os.path.join(dest, rel)
    if os.path.exists(p):
        key = f"{name}:{rel.split('/')[0]}"
        reg[key] = {"command": cmd[0], "args": [cmd[1].format(dir=dest)]}
        found.append(key)
json.dump(reg, open(reg_path, "w"), indent=1)
print("MCP:" + (", ".join(found) if found else "none"))
PY

# 4) optional python deps
if [ "$WITH_DEPS" = "1" ] && [ -f "$DEST/requirements.txt" ]; then
  PY="$EDITOR/venv/bin/pip"; [ -x "$PY" ] || PY=pip3
  say "installing python requirements (this can take a minute)"
  "$PY" install -q -r "$DEST/requirements.txt" >>"$LOG" 2>&1 && say "deps: ok" || say "deps: failed (see log)"
fi

# 5) tell the bot about it
{
  echo ""
  echo "## Installed from $SRC_URL"
  echo "- repo path: $DEST"
  [ "$INSTALLED" -gt 0 ] && echo "- skills copied into $SKILLDIR ($INSTALLED files). Read the matching SKILL.md before using one."
  echo "- MCP servers (if any) are registered in $CLAW/state/mcp-registry.json; start one with its command before calling it."
  echo "- If this repo is an editor/tool, call its entry point through $EDITOR/venv/bin/python, never install system packages."
} >> "$WS/AGENTS.md"

say "OK $NAME installed. skills_files=$INSTALLED"
say "DONE"
