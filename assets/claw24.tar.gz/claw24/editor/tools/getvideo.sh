#!/usr/bin/env bash
# getvideo.sh <url> [outdir] -> prints "OK <path>" or "FAIL <reason>"
set -uo pipefail
URL="${1:?url}"; OUT="${2:-$HOME/openclaw/workspace/downloads}"
mkdir -p "$OUT"
isvid() { ffprobe -v error -select_streams v:0 -show_entries stream=codec_type -of csv=p=0 "$1" 2>/dev/null | grep -q video; }
id="$(date +%s)"
try() { echo "  trying: $*" >&2; }

# 1) yt-dlp handles YouTube/TikTok/Insta/X/Twitch/Vimeo/Direct AND Google Drive
try "yt-dlp"
if command -v yt-dlp >/dev/null; then
  p="$OUT/v_$id.mp4"
  if yt-dlp --no-warnings --no-playlist -f "bv*[height<=1080][ext=mp4]+ba[ext=m4a]/b[ext=mp4]/b" \
       --merge-output-format mp4 -o "$p" "$URL" >/dev/null 2>"$OUT/err_$id.txt"; then
     [ -s "$p" ] && isvid "$p" && { echo "OK $p"; exit 0; }
  fi
  echo "  yt-dlp said: $(tail -2 "$OUT/err_$id.txt" | tr '\n' ' ')" >&2
fi

# 2) Google Drive direct with confirm token (works when "anyone with link")
if [[ "$URL" == *drive.google.com* ]]; then
  try "drive-direct"
  FID=$(printf '%s' "$URL" | sed -n 's#.*/file/d/\([^/]*\)/.*#\1#p'); [ -z "$FID" ] && FID=$(printf '%s' "$URL" | sed -n 's#.*[?&]id=\([^&]*\).*#\1#p')
  if [ -n "$FID" ]; then
    p="$OUT/v_$id.mp4"; ck="$OUT/ck_$id.txt"
    curl -sc "$ck" -L "https://drive.google.com/uc?export=download&id=$FID" -o "$p" >/dev/null 2>&1
    if grep -qi "confirm" "$p" 2>/dev/null || [ "$(stat -c%s "$p" 2>/dev/null || echo 0)" -lt 100000 ]; then
      TOK=$(grep -o 'confirm=[A-Za-z0-9_-]*' "$p" 2>/dev/null | head -1 | cut -d= -f2)
      UUID=$(grep -o 'name="uuid" value="[^"]*"' "$p" 2>/dev/null | head -1 | sed 's/.*value="//;s/"//')
      curl -sb "$ck" -L "https://drive.usercontent.google.com/download?id=$FID&export=download&confirm=t${TOK:+&confirm=$TOK}${UUID:+&uuid=$UUID}" -o "$p" >/dev/null 2>&1
    fi
    sz=$(stat -c%s "$p" 2>/dev/null || echo 0)
    if [ "$sz" -gt 100000 ] && isvid "$p"; then echo "OK $p"; exit 0; fi
    echo "  drive returned $(head -c 120 "$p" | tr -d '\0' | tr '\n' ' ')" >&2
  fi
fi

# 3) plain direct file
try "curl"
p="$OUT/v_$id.mp4"
curl -sfL -m 180 "$URL" -o "$p" >/dev/null 2>&1 && [ "$(stat -c%s "$p" 2>/dev/null || echo 0)" -gt 100000 ] && isvid "$p" && { echo "OK $p"; exit 0; }

echo "FAIL could not download. If this is a Google Drive file: open it, Share -> Anyone with the link -> Viewer, then send the link again. YouTube/other links failing: make sure the video is public, not private."
exit 1
