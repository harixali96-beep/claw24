#!/usr/bin/env bash
# getvideo.sh <url> [outdir] -> prints "OK <path>" or "FAIL <reason>"
# Platform-aware downloader: Twitch, Kick, TikTok, Instagram, X, Facebook, Vimeo,
# Dailymotion, direct mp4/m3u8, Google Drive, and YouTube when a cookies file exists.
set -uo pipefail
URL="${1:?usage: getvideo.sh <url> [outdir]}"
OUT="${2:-$HOME/downloads}"
mkdir -p "$OUT"
ID="$(date +%s)$RANDOM"
COOKIES="${YOUTUBE_COOKIES:-${CLAW:-$HOME/claw}/state/cookies.txt}"
MAXH="${MAX_HEIGHT:-720}"

isvid() { ffprobe -v error -select_streams v:0 -show_entries stream=codec_type -of csv=p=0 "$1" 2>/dev/null | grep -q video; }
say() { echo "  $*" >&2; }

YTDLP=(yt-dlp --no-warnings --no-playlist --newline
       -f "bv*[height<=${MAXH}][ext=mp4]+ba[ext=m4a]/b[height<=${MAXH}]/bv*[height<=${MAXH}]+ba/b"
       --merge-output-format mp4 --retries 5 --fragment-retries 10 --concurrent-fragments 4)

# cookies: only for YouTube and only if the file is a real netscape cookie jar
if [ -f "$COOKIES" ] && head -5 "$COOKIES" 2>/dev/null | grep -qE "Netscape|youtube\.com"; then
  YTDLP+=(--cookies "$COOKIES")
  say "cookies: using $COOKIES"
fi

case "$URL" in
  *drive.google.com*|*docs.google.com*)
    say "platform: google drive"
    FID=$(printf '%s' "$URL" | sed -n 's#.*/file/d/\([^/]*\)/.*#\1#p')
    [ -z "$FID" ] && FID=$(printf '%s' "$URL" | sed -n 's#.*[?&]id=\([^&]*\).*#\1#p')
    p="$OUT/v_$ID.mp4"; ck="$OUT/ck_$ID.txt"
    curl -sc "$ck" -L "https://drive.google.com/uc?export=download&id=$FID" -o "$p" >/dev/null 2>&1
    if [ "$(stat -c%s "$p" 2>/dev/null || echo 0)" -lt 200000 ]; then
      UUID=$(grep -o 'name="uuid" value="[^"]*"' "$p" 2>/dev/null | head -1 | sed 's/.*value="//;s/"//')
      curl -sb "$ck" -L "https://drive.usercontent.google.com/download?id=$FID&export=download&confirm=t${UUID:+&uuid=$UUID}" -o "$p" >/dev/null 2>&1
    fi
    if isvid "$p"; then echo "OK $p"; exit 0; fi
    echo "FAIL Drive file accessible nahi hai. Share -> Anyone with the link -> Viewer karo, phir link dobara bhejo."
    exit 1;;
  *.mp4|*.mov|*.mkv|*.webm|*.m4v|*.m3u8)
    say "platform: direct file"
    p="$OUT/v_$ID.mp4"
    if ffmpeg -y -v error -i "$URL" -c copy "$p" >/dev/null 2>&1 && isvid "$p"; then echo "OK $p"; exit 0; fi;;
esac

# live streams: record a fixed window instead of waiting for the stream to end
if printf '%s' "$URL" | grep -qiE "twitch\.tv/[^/]+/?$|kick\.com/[^/]+/?$"; then
  ISLIVE=$(yt-dlp --no-warnings --simulate --print "%(is_live)s" "$URL" 2>/dev/null | head -1)
  if [ "$ISLIVE" = "True" ]; then
    MIN="${LIVE_MINUTES:-10}"
    say "live stream detected: recording ${MIN} minutes"
    p="$OUT/v_$ID.mp4"
    yt-dlp --no-warnings --downloader ffmpeg --downloader-args "ffmpeg_i:-t $((MIN*60))" \
           -f "b[height<=${MAXH}]/b" -o "$p" "$URL" >/dev/null 2>"$OUT/err_$ID.txt"
    if isvid "$p"; then echo "OK $p"; exit 0; fi
    say "live record said: $(tail -2 "$OUT/err_$ID.txt" | tr '\n' ' ')"
  fi
fi

say "platform: yt-dlp"
p="$OUT/v_$ID.mp4"
if "${YTDLP[@]}" -o "$p" "$URL" >/dev/null 2>"$OUT/err_$ID.txt" && isvid "$p"; then
  echo "OK $p"; exit 0
fi
ERR="$(tail -4 "$OUT/err_$ID.txt" 2>/dev/null | tr '\n' ' ')"

if printf '%s' "$ERR" | grep -qi "Sign in to confirm"; then
  echo "FAIL YouTube is server ke IP ko block kar raha hai (bot check). 3 hal hain: (1) apna cookies.txt ek dafa bhejo, phir YouTube hamesha chalega, (2) video file Telegram par bhejo, (3) Drive par public link banao. Twitch, Kick, TikTok, Instagram, X, Facebook, Vimeo, Drive aur direct links bina cookies chalte hain."
elif printf '%s' "$ERR" | grep -qiE "Private video|members-only|age"; then
  echo "FAIL Video private ya age-restricted hai, is liye download nahi ho saka."
elif printf '%s' "$ERR" | grep -qiE "Unsupported URL|is not a valid URL"; then
  echo "FAIL Ye link support nahi hua. Poora video ya clip ka link bhejo (channel ka home page nahi)."
else
  echo "FAIL download nahi hua: ${ERR:0:200}"
fi
exit 1
