#!/usr/bin/env python3
"""Professional short-form editor: smart window + fast cuts + burned captions + sfx + 9:16.
Usage: proedit.py <src> <outdir> [--seconds 20] [--n 2] [--style NAME] [--text "extra ops"]"""
import sys, os, json, argparse
CHATCUT = os.environ.get("CHATCUT_DIR", "/app/conversations/6afc1d1d8ad6c9c4ce1391f4/chatcut")
sys.path.insert(0, CHATCUT)
import engine, transcribe, autoclip  # noqa

ap = argparse.ArgumentParser()
ap.add_argument("src"); ap.add_argument("outdir")
ap.add_argument("--seconds", type=float, default=20.0)
ap.add_argument("--n", type=int, default=1)
ap.add_argument("--style", default=None)
ap.add_argument("--text", default="")
ap.add_argument("--fastcut", type=float, default=0.0, help="seconds per shot; adds hard cuts + whoosh/impact sfx")
ap.add_argument("--sfx-dir", default=None, help="folder with the sfx bank + catalog.json")

def fast_cut(src, dst, chunk, workdir, sfx_dir=None):
    """Hard cuts every <chunk> seconds + whoosh/impact sfx on each cut point."""
    total = float(engine.probe(src).get("duration") or 0)
    n = max(1, int(total // chunk))
    parts, t = [], 0.0
    for k in range(n):
        seg = os.path.join(workdir, f"seg_{os.path.basename(dst)}_{k}.mp4")
        engine.run([engine.FFMPEG, "-y", "-v", "error", "-ss", str(round(t, 2)), "-t", str(chunk),
                    "-i", src, "-vf", f"scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920",
                    "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-c:a", "aac", "-b:a", "160k", seg])
        parts.append(seg); t += chunk
    if total - t > 0.4:
        seg = os.path.join(workdir, f"seg_{os.path.basename(dst)}_tail.mp4")
        engine.run([engine.FFMPEG, "-y", "-v", "error", "-ss", str(round(t, 2)), "-i", src,
                    "-vf", "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920",
                    "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-c:a", "aac", "-b:a", "160k", seg])
        parts.append(seg)
    lst = os.path.join(workdir, f"list_{os.path.basename(dst)}.txt")
    open(lst, "w").write("\n".join(f"file '{os.path.abspath(q)}'" for q in parts) + "\n")
    joined = os.path.join(workdir, f"joined_{os.path.basename(dst)}.mp4")
    engine.run([engine.FFMPEG, "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", lst,
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-c:a", "aac", joined])
    whoosh = impact = None
    if sfx_dir:
        cat_path = os.path.join(sfx_dir, "catalog.json")
        if os.path.exists(cat_path):
            cat = json.load(open(cat_path))
            def pick(fam):
                for e in cat:
                    if e.get("family") == fam and os.path.exists(os.path.join(sfx_dir, e["file"])):
                        return os.path.join(sfx_dir, e["file"])
                return None
            whoosh, impact = pick("whoosh"), pick("impact")
    if not (whoosh and impact):
        whoosh, impact = engine.make_sfx(workdir)
    inputs, filters, mix = ["-i", joined, "-i", whoosh, "-i", impact], [], []
    for k in range(1, len(parts)):
        at = round(k * chunk, 2)
        which, vol = (1, 0.5) if k % 2 else (2, 0.75)
        mix.append(f"[{which}:a]volume={vol},adelay={int(at*1000)}|{int(at*1000)}[s{k}]")
        inputs += []
    labels = "[0:a]" + "".join(f"[s{k}]" for k in range(1, len(parts)))
    filters = mix + [f"{labels}amix=inputs={len(parts)}+0:dropout_transition=0:normalize=0[aout]"]
    engine.run([engine.FFMPEG, "-y", "-v", "error", *inputs, "-filter_complex", ";".join(filters),
                "-map", "0:v", "-map", "[aout]", "-c:v", "copy", "-c:a", "aac", "-b:a", "160k", dst])
    return dst

a = ap.parse_args()
os.makedirs(a.outdir, exist_ok=True)
dur = float(engine.probe(a.src).get("duration") or 0)
rep = {"src": a.src, "src_duration": round(dur, 2), "clips": [], "warnings": []}

srt_full = os.path.join(a.outdir, "full.srt")
tr = {"segments": [], "srt": "", "word_count": 0}
try:
    tr = transcribe.transcribe(a.src)
    open(srt_full, "w", encoding="utf-8").write(tr.get("srt") or "")
except Exception as e:
    rep["warnings"].append(f"transcribe failed: {e}")
segs = tr.get("segments") or []
rep["word_count"] = tr.get("word_count", 0)

ops_text = "vertical 1080x1920 captions sfx " + (a.text or "")
plan = []
if dur > a.seconds + 3 and segs:
    cands = autoclip.build_candidates(segs, min_len=max(6.0, a.seconds - 4), max_len=a.seconds + 4)
    for c in cands:
        sc, br = autoclip.score_window(c)
        c["score"], c["score_breakdown"] = sc, br
    plan = autoclip.pick(cands, n=a.n) or []
if plan:
    for i, c in enumerate(plan, 1):
        w_srt = os.path.join(a.outdir, f"window{i}.srt")
        autoclip.window_srt(segs, c["start"], c["end"], w_srt)
        cut = os.path.join(a.outdir, f"cut{i}.mp4")
        engine.run(["ffmpeg", "-y", "-v", "error", "-ss", str(c["start"]), "-t", str(round(c["end"] - c["start"], 2)),
                    "-i", a.src, "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
                    "-c:a", "aac", "-b:a", "160k", cut])
        if a.fastcut and a.fastcut > 0.5:
            fc = os.path.join(a.outdir, f"fc{i}.mp4")
            fast_cut(cut, fc, a.fastcut, a.outdir, a.sfx_dir)
            cut = fc
        out = os.path.join(a.outdir, f"clip{i}.mp4")
        r = engine.edit(cut, ops_text, out, srt=w_srt, style=a.style)
        rep["clips"].append({"output": r.get("output"), "window": [round(c["start"], 2), round(c["end"], 2)],
                             "duration": round(float(engine.probe(r.get("output") or "").get("duration") or 0), 2),
                             "steps": [s.get("op") for s in r.get("steps", [])]})
else:
    out = os.path.join(a.outdir, "clip1.mp4")
    r = engine.edit(a.src, ops_text, out, srt=srt_full if rep["word_count"] else None, style=a.style)
    rep["clips"].append({"output": r.get("output"), "duration": round(float(engine.probe(r.get("output") or "").get("duration") or 0), 2),
                         "steps": [s.get("op") for s in r.get("steps", [])]})
    if not rep["word_count"]:
        rep["warnings"].append("no speech detected -> captions empty")

ok = [c for c in rep["clips"] if c.get("output") and os.path.exists(c["output"])]
rep["ok"] = bool(ok)
for c in ok:
    p = engine.probe(c["output"])
    c["size"] = f"{p.get('width')}x{p.get('height')}"
    c["has_audio"] = bool(p.get("has_audio") if "has_audio" in p else True)
print(json.dumps(rep, indent=1))
